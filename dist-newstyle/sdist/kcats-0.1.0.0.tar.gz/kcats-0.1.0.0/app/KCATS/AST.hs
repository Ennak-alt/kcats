{-# LANGUAGE InstanceSigs #-}
module KCATS.AST where
import Data.List
import Data.Vector

class Stack c where
    push :: a -> c a -> c a
    swapI :: Int -> c a -> c a
    swap :: c a -> c a
    swap = swapI 1
    modifyTop :: (a -> a) -> c a -> c a

instance Stack [] where
    push :: a -> [a] -> [a]
    push x s = x : s
    swapI 0 s = s
    swapI i s = let (x:xs, y:ys) = splitAt i s in y:xs ++ x:ys
    modifyTop f (x:xs) = f x : xs

newtype StackList a = Stack ([] a)

newtype EvalM a = EvalM (StackList a -> Either String a)

data INST 
    = ADDI Integer
    | ADD 
    | SUB
    | SWAP
    | PUSHZ
    | XOR
    | POPZ

eval []







